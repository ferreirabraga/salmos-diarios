'use strict';

// module.exports.hello = async (event) => {
//   return {
//     statusCode: 200,
//     body: JSON.stringify({
//       message: 'Go Serverless v1.0! Your function executed successfully!',
//       input: event,
//     }, null, 2),
//   };

//   // Use this code if you don't use the http event with the LAMBDA-PROXY integration
//   // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
// };

module.exports.hello = (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  //let bodyP = JSON.parse(event.body);
  //util.mostraLog(" formulario ", bodyP);
  //let cadastroSenhaLogin = {};
  //cadastroSenhaLogin.email1 = bodyP.email; 
  //cadastroSenhaLogin.hashSenha = bodyP.senha;

  return buscarSalmo()
    .then(function (value) {
      util.mostraLog("fazendo login", value);
      return ({
        statusCode: 200,
        body: JSON.stringify(value)
      })
    })
    .catch(err => ({
      statusCode: err.statusCode || 500,
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify({ message: err.message })
    }));
};


function buscarSalmo(dadosFazLogin) {
  let resposta = {};
  return new Promise(function (resolve, reject) {
    if (resposta.length < 1) {
    
      MongoClient.connect(process.env.DB, function (err, db) {
        if (err) throw err;
        let database = db.db(constantsDb.DATABASE);
        util.mostraLog("email1:", dadosFazLogin);
        let query = {"email1":dadosFazLogin.email1, "senhaUser": dadosFazLogin.hashSenha}
        util.mostraLog("query:", query);
        database.collection(constantsDb.TABELA_USUARIO)
          .find(query)
          .toArray((err, results) => {
            if (err) throw err;
            if (results.length > 0) {
              // util.mostraLog(" fazendo login :", results);
              let user = {};
              user.username = dadosFazLogin.email1;
              user.scopes = constantsDb.SCOPES;
              let resp = {};
              resp.id = results[0]._id;
              resp.nome = results[0].nome;
              resp.numeroCelular = results[0].numeroCelular;
              resp.email = results[0].email1;
              const token = jwt.sign({ user }, process.env.JWT_SECRET, { expiresIn: constantsDb.JWT_EXPIRATION_TIME });
              console.log(`JWT issued: ${token}`);
              resposta = { "codigo": "1", "mensagem": "Login efetuado com sucesso", "token": token, "usuario": resp };
              db.close();
              resolve(resposta);          
            } else {
              util.mostraLog('Caught an error!', err);
              resposta = { "codigo": "0", "mensagem": "Usuário e senha inválidos." };
              db.close();
              resolve(resposta);
            }
            db.close();
          });
      })
    } else {
      resolve(resposta);
    }
  });
}
